declare module 'file-saver';
declare module 'html2pdf.js';
