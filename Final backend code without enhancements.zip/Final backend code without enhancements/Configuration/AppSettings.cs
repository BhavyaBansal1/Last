namespace WisVestAPI.Configuration
{
    public class AppSettings
    {
        public string ProductJsonFilePath { get; set; }
        public string OutputJsonFilePath { get; set; }
    }
}